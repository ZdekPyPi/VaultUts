#TEST FILE
from dotenv import load_dotenv
import sys
import os
sys.path.append("./vaultUts")
from vaultUts import *
load_dotenv()






